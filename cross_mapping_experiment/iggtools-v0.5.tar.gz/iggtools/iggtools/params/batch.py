default_branch = "master"
default_queue = "pairani"
default_memory = 378880
default_vcpus = 48
default_ecr_image = "pairani:latest"
