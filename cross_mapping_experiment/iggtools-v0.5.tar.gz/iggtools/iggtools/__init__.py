"""iggtools"""

import sys
assert sys.version_info >= (3, 7), "Python version >= 3.7 is required."

version = "0.50"
